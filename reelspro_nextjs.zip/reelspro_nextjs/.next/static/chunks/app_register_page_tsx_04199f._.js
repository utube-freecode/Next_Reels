(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_register_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_register_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/_7a5863._.js"
  ],
  "source": "dynamic"
});
