import ImageKit from "imagekit"
import { NextResponse } from "next/server";

//TODO: Import from .env file

var imagekit = new ImageKit({
    publicKey : "public_DnEwl6An3P7AnTN6U2WeMUIrQxI=",
    privateKey : "private_xqlPYugqBupkEnoF+IuL3CNpaKs=",
    urlEndpoint : "https://ik.imagekit.io/ggcqky8r7"
})


export async function GET() {
    try {
        return NextResponse.json(imagekit.getAuthenticationParameters());
    } catch (error) {
        return NextResponse.json(
            {error : "Imagekit auth failed"},
            {status : 500}
        )
    }
}