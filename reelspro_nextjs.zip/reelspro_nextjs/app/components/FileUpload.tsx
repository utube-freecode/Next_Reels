"use client";
import React, { useRef, useState } from "react";
import { ImageKitProvider, IKImage, IKUpload } from "imagekitio-next";
import { Loader2 } from "lucide-react";
import { IKUploadResponse } from "imagekitio-next/dist/types/components/IKUpload/props";


interface FileUploadProps  {
    onSuccess : (res : IKUploadResponse) => void
    onProgress? : (progress : number) => void
    fileType? : "image" | "video"
}


export default function FileUpload({onSuccess, onProgress, fileType = "image"} : FileUploadProps) {

  const [uploading, setUploading] = useState(false)
  console.log(uploading, "uploading")
  const [error, setError] = useState<string | null>(null)

  const onError = (err : {message : string}) => {
    console.log("Error", err);
    setError(err?.message)
    setUploading(false)
  };
  
  const handleSuccess = (response : IKUploadResponse) => {
    console.log("Success", response);
    setUploading(false)
    setError(null)
    onSuccess(response)
  };
  
  const handleUploadProgress = (evt : ProgressEvent) => {
    console.log(evt,"evt")
    if(evt.lengthComputable && onProgress){
        const percetageComplete = (evt.loaded / evt.total) * 100
        onProgress(Math.round(percetageComplete))
    }
  };
  
  const handleUploadStart = () => {
    console.log("Upload started")
    setUploading(true)
    setError(null)
  };

  const validateFile = (file : File) => {
    if(fileType === "video"){
      console.log("Validate file, video")
        if(!file.type.startsWith("video/")){
            console.log("Please upload a video file")
            setError("Please upload a video file")
            return false
        }
        // file size greater than 100mb
        if(file.size > 100 * 1024 * 1024){
            console.log("Video must be less than 100MB")
            setError("Video must be less than 100MB")
            return false
        }
    }
    else{
        const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"]
        if(!validTypes.includes(file.type)){
            setError("Please uploda a valid file (JPEG, PNG, WEBP, JPG)")
            return false
        }
        if(file.size > 5 * 1024 * 1024){
            setError("Image must be less than 5MB")
            return false
        }
    }
    return true
  }


  return (
    <div className="space-y-2">
        <IKUpload
          fileName={fileType === "video" ? "videotest" : "imagetest"}
          useUniqueFileName={true}
          validateFile={(file) => validateFile(file)}
          onError={onError}
          onSuccess={handleSuccess}
          onUploadProgress={handleUploadProgress}
          onUploadStart={handleUploadStart}
          accept={fileType === "video" ? "video/*" : "image/*"}
          className="file-input file-input-bordered w-full"
          folder={fileType === "video" ? '/videos' : '/images'}
        />
        {
            uploading && (
                <div className="flex items-center gap-2 text-sm text-primary">
                    <Loader2 className="animate-spin w-4 h-4"/>
                    <span >Uploading...</span>
                </div>
            )
        }
        {error && (
            <div className="text-error text-sm">{error}</div>
        )}
    </div>
  );
}