"use client"

import { ImageKitProvider, IKImage, IKVideo } from "imagekitio-next";
import { SessionProvider } from "next-auth/react";
import NotificationProvider from "./Notification";

//TODO: Import from .env file
const publicKey = "public_DnEwl6An3P7AnTN6U2WeMUIrQxI="
const urlEndpoint = "https://ik.imagekit.io/ggcqky8r7"

export default function Providers({children} : {children : React.ReactNode}) {

    const authenticator = async () => {
    try {
        const response = await fetch("/api/imagekit-auth");

        if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Request failed with status ${response.status}: ${errorText}`);
        }

        const data = await response.json();
        console.log(data, "signatue")
        const {signature, expire, token} = data
        return {signature, expire, token}

    } catch (error) {
        console.log(error)
        throw new Error(`Imagekit Authentication request failed `);
    }
    };


    return (
        <SessionProvider refetchInterval={5 * 60}>
            <NotificationProvider>
                <ImageKitProvider urlEndpoint={urlEndpoint} publicKey={publicKey} authenticator={authenticator}>
                    {children}
                </ImageKitProvider>
            </NotificationProvider>
        </SessionProvider>
    );
}